package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class TeacherController {

//	*****LABELS*****
	@FXML
	Label faculty_id_lbl;

	@FXML
	Label faculty_name_lbl;

	@FXML
	Label f_contact_lbl;

	@FXML
	Label f_email_lbl;

	@FXML
	Label f_DeptID_lbl;

	@FXML
	Label f_gender_lbl;

//	*****BUTTONS*****
	@FXML
	Button f_logout_btn;

	@FXML
	Button f_Home_btn;

	@FXML
	Button f_Exit_btn;

	@FXML
	Button f_attendance_btn;

	@FXML
	Button f_grades_btn;

	@FXML
	Button markAttendance_btn;

	@FXML
	Button f_search_btn;

	@FXML
	Button f_view_attendance_btn;
//	****	PANES	*****
	@FXML
	AnchorPane TeacherHomePane;

	@FXML
	AnchorPane FacultyAttendancePane;

	@FXML
	AnchorPane FacultyViewAttendancePane;

//	*****	TABLES	*****
	public TableView<ObservableList<String>> attendanceTable;

//	*****	COMBO-BOXES	*****
	@FXML
	ComboBox<String> semesterComboBox;

	@FXML
	ComboBox<String> courseComboBox;

	@FXML
	ComboBox<String> sectionComboBox;

//	*****	STORING THE FACULTY DATA FETCHED FROM THE DATABASE INTO A HASHMAP	*****
	public static Map<String, String> facultyData = new HashMap<>();

	public static Map<String, String> getFacultyData() {
		return facultyData;
	}

	public String getFacultyID() {
		return facultyData.get("FACULTY_ID");
	}

	public String getFirstName() {
		return facultyData.get("FIRSTNAME");
	}

	public String getLastName() {
		return facultyData.get("LASTNAME");
	}

	public String getGender() {
		return facultyData.get("GENDER");
	}

	public String getDeptId() {
		return facultyData.get("DEPT_ID");
	}

	public String getEmail() {
		return facultyData.get("EMAIL");
	}

	public String getContact() {
		return facultyData.get("CONTACT");
	}

//	*****	INITIALIZATION FUNCTIONS	*****
	public void initialize() {
		initializeComboBox();
//		markAttendanceInitialize();
		f_search_btn.setOnAction(event -> handleSearchButtonClick());
	}

	public void initializeFacultyData(String facultyId) {
		String id = facultyId;

		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(
						"SELECT FACULTY_ID, FIRSTNAME, LASTNAME, GENDER, DEPT_ID, CONTACT, EMAIL FROM FACULTY WHERE FACULTY_ID = ?")) {

			preparedStatement.setString(1, facultyId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					facultyData.put("FACULTY_ID", resultSet.getString("FACULTY_ID"));
					facultyData.put("FIRSTNAME", resultSet.getString("FIRSTNAME"));
					facultyData.put("LASTNAME", resultSet.getString("LASTNAME"));
					facultyData.put("GENDER", resultSet.getString("GENDER"));
					facultyData.put("DEPT_ID", resultSet.getString("DEPT_ID"));
					facultyData.put("CONTACT", resultSet.getString("CONTACT"));
					facultyData.put("EMAIL", resultSet.getString("EMAIL"));

					faculty_id_lbl.setText(resultSet.getString("FACULTY_ID"));
					faculty_name_lbl.setText(resultSet.getString("FIRSTNAME") + " " + resultSet.getString("LASTNAME"));
					f_gender_lbl.setText(resultSet.getString("GENDER"));
					f_DeptID_lbl.setText(resultSet.getString("DEPT_ID"));
					f_contact_lbl.setText(resultSet.getString("CONTACT"));
					f_email_lbl.setText(resultSet.getString("EMAIL"));
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

//	*****	ATTENDANCE	*****
	void initializeComboBox() {
		// Fetch and populate semesterComboBox
		semesterComboBox.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8");
		sectionComboBox.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8");

		// Set action listeners to update other combo boxes
		semesterComboBox.setOnAction(event -> updateCourseComboBox());
		updateCourseComboBox();

	}

	void updateCourseComboBox() {
		// Fetch and populate courseComboBox based on selected semester and department
		String selectedSemester = semesterComboBox.getValue();
		String selectedDepartment = getDeptId();

		List<String> courses = new ArrayList<>(); // Create a list to store courses

		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT COURSENAME FROM COURSE WHERE sem_offered = ? AND DEPT_ID = ?")) {

			preparedStatement.setString(1, selectedSemester);
			preparedStatement.setString(2, selectedDepartment);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					courses.add(resultSet.getString("COURSENAME"));
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Set the list of courses to the combo box
		courseComboBox.getItems().setAll(courses);

		// If there are items in the combo box, select the first one
		if (!courses.isEmpty()) {
			courseComboBox.getSelectionModel().selectFirst();
		}
	}

	void markAttendanceInitialize() {
		// Get the selected values from ComboBoxes
		String selectedSemester = semesterComboBox.getValue().toString();
		String selectedCourse = courseComboBox.getValue().toString();
		String selectedSection = sectionComboBox.getValue().toString();

		// Display student records in the TableView based on the selected values
		displayStudentRecords(selectedSemester, selectedCourse, selectedSection);
	}

	void displayStudentRecords(String semester, String course, String section) {
		// Implement logic to fetch student records from the database based on the
		// selected values
		ObservableList<ObservableList<String>> studentData = fetchStudentRecordsFromDatabase(semester, course, section);

		// Clear existing columns and items
		attendanceTable.getColumns().clear();
		attendanceTable.getItems().clear();

		if (!studentData.isEmpty()) {
			try {
				ResultSetMetaData metaData = getResultSetMetaData(semester, course, section);
				int columnCount = metaData.getColumnCount();

				for (int i = 1; i <= columnCount; i++) {
					final int colIdx = i - 1;
					TableColumn<ObservableList<String>, String> column = new TableColumn<>(metaData.getColumnName(i));
					column.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue().get(colIdx)));
					attendanceTable.getColumns().add(column);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		// Set the data in the TableView
		attendanceTable.setItems(studentData);
	}

	ResultSetMetaData getResultSetMetaData(String semester, String course, String section) throws SQLException {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT S.STUDENT_ID, S.FIRSTNAME, S.LASTNAME " + "FROM STUDENT S "
								+ "JOIN COURSEREGISTRATION CR ON S.STUDENT_ID = CR.STUDENT_ID "
								+ "JOIN COURSE C ON CR.COURSE_ID = C.COURSE_ID "
								+ "WHERE C.COURSENAME = ? AND C.sem_offered = ? AND S.SECTION_ID = ?")) {

			preparedStatement.setString(1, course);
			preparedStatement.setString(2, semester);
			preparedStatement.setString(3, section);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				return resultSet.getMetaData();
			}
		}
	}

	ObservableList<ObservableList<String>> fetchStudentRecordsFromDatabase(String semester, String course,
			String section) {
		ObservableList<ObservableList<String>> studentData = FXCollections.observableArrayList();

		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT S.STUDENT_ID, S.FIRSTNAME, S.LASTNAME " + "FROM STUDENT S "
								+ "JOIN COURSEREGISTRATION CR ON S.STUDENT_ID = CR.STUDENT_ID "
								+ "JOIN COURSE C ON CR.COURSE_ID = C.COURSE_ID "
								+ "WHERE C.COURSENAME = ? AND C.sem_offered = ? AND S.SECTION_ID = ?")) {

			preparedStatement.setString(1, course);
			preparedStatement.setString(2, semester);
			preparedStatement.setString(3, section);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					ObservableList<String> row = FXCollections.observableArrayList();
					row.add(resultSet.getString("STUDENT_ID"));
					row.add(resultSet.getString("FIRSTNAME"));
					row.add(resultSet.getString("LASTNAME"));
					studentData.add(row);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return studentData;
	}

	void handleSearchButtonClick() {
		// Get the selected values from ComboBoxes
		String selectedSemester = semesterComboBox.getValue().toString();
		String selectedCourse = courseComboBox.getValue().toString();
		String selectedSection = sectionComboBox.getValue().toString();

		// Display student records in the TableView based on the selected values
		displayStudentRecords(selectedSemester, selectedCourse, selectedSection);
	}

//	 ***** SCENE FUNCTIONS FOR HOMESCREEN *****
	public void Logout() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
			Parent loginScene = loader.load();
			Scene scene = new Scene(loginScene);
			Stage stage = (Stage) f_logout_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void attendance() {
		TeacherHomePane.setVisible(false);
		FacultyAttendancePane.setVisible(true);
	}

//	*****	SCENE FUNCTIONS FOR ATTENDANCE SCREEN	*****
	public void Home() {
		FacultyAttendancePane.setVisible(false);
		TeacherHomePane.setVisible(true);
	}

	public void ViewAttendance() {
		FacultyAttendancePane.setVisible(false);
	}

	// ***** MISCELLANEOUS FUNCTIONS *****
	private void showAlert(String title, String content, Alert.AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}
}
