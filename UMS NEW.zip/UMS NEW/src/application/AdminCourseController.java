package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminCourseController {

	@FXML
	Button home_btn;

	@FXML
	Button logout_btn;

	@FXML
	Button add_btn;

	@FXML
	Button delete_btn;

	@FXML
	Button update_btn;

	@FXML
	Button reset_btn;

	@FXML
	Button exit_btn;

	@FXML
	TextField search_tf;

	@FXML
	TextField courseID_tf;

	@FXML
	TextField CName;

	@FXML
	TextField DeptID;

	@FXML
	TextField lecture;

	@FXML
	TextField lab;

	@FXML
	TextField semoffer;

	@FXML
	TableView<ObservableList<Object>> CourseTable;

	@FXML
	public void initialize() {
		search_tf.textProperty().addListener((observable, oldValue, newValue) -> searchCourse(newValue));
		getCourseData();
	}

	public void getCourseData() {
		try (Connection connection = Database.establishConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM course")) {

			// Clear existing items in the TableView
			CourseTable.getItems().clear();
			CourseTable.getColumns().clear();

			// Create columns dynamically based on the result set metadata
			for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
				final int j = i - 1;
				TableColumn<ObservableList<Object>, Object> column = new TableColumn<>(
						resultSet.getMetaData().getColumnName(i));
				column.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
				CourseTable.getColumns().add(column);
			}

			// Add data to the TableView
			ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();
			while (resultSet.next()) {
				ObservableList<Object> row = FXCollections.observableArrayList();
				for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
					row.add(resultSet.getObject(i));
				}
				data.add(row);
			}
			CourseTable.setItems(data);

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	// ***** CRUD OPERATIONS FOR COURSE *****
	public void addCourse() {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(
						"INSERT INTO course (COURSE_ID, COURSENAME, DEPT_ID, lecture_credit, lab_credit, sem_offered) VALUES (?, ?, ?, ?, ?, ?)")) {

			preparedStatement.setString(1, courseID_tf.getText());
			preparedStatement.setString(2, CName.getText());
			preparedStatement.setString(3, DeptID.getText());
			preparedStatement.setInt(4, Integer.parseInt(lecture.getText()));
			preparedStatement.setInt(5, Integer.parseInt(lab.getText()));
			preparedStatement.setInt(6, Integer.parseInt(semoffer.getText()));

			int affectedRows = preparedStatement.executeUpdate();
			if (affectedRows > 0) {
				showAlert("Success", "Course added successfully.", Alert.AlertType.INFORMATION);
				reset();
				getCourseData(); // Refresh the table
			} else {
				showAlert("Error", "Failed to add course.", Alert.AlertType.ERROR);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	// Function to delete a course
	public void deleteCourse() {
		ObservableList<Object> selectedRow = CourseTable.getSelectionModel().getSelectedItem();

		if (selectedRow != null) {
			String courseIdToDelete = selectedRow.get(0).toString(); // Assuming COURSE_ID is in the first column

			try (Connection connection = Database.establishConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement("DELETE FROM course WHERE COURSE_ID = ?")) {

				preparedStatement.setString(1, courseIdToDelete);

				int affectedRows = preparedStatement.executeUpdate();
				if (affectedRows > 0) {
					showAlert("Success", "Course deleted successfully.", Alert.AlertType.INFORMATION);
					reset();
					getCourseData(); // Refresh the table
				} else {
					showAlert("Error", "Failed to delete course. Course ID not found.", Alert.AlertType.ERROR);
				}

			} catch (SQLException e) {
				e.printStackTrace();
				showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
			}
		} else {
			showAlert("Error", "Please select a row to delete.", Alert.AlertType.ERROR);
		}
	}

	// Function to update a course
	public void updateCourse() {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(
						"UPDATE course SET COURSENAME = ?, DEPT_ID = ?, lecture_credit = ?, lab_credit = ?, sem_offered = ? WHERE COURSE_ID = ?")) {

			preparedStatement.setString(1, CName.getText());
			preparedStatement.setString(2, DeptID.getText());
			preparedStatement.setInt(3, Integer.parseInt(lecture.getText()));
			preparedStatement.setInt(4, Integer.parseInt(lab.getText()));
			preparedStatement.setInt(5, Integer.parseInt(semoffer.getText()));
			preparedStatement.setString(6, courseID_tf.getText());

			int affectedRows = preparedStatement.executeUpdate();
			if (affectedRows > 0) {
				showAlert("Success", "Course updated successfully.", Alert.AlertType.INFORMATION);
				reset();
				getCourseData(); // Refresh the table
			} else {
				showAlert("Error", "Failed to update course. Course ID not found.", Alert.AlertType.ERROR);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	private void searchCourse(String searchText) {
		searchText = searchText.trim();

		if (!searchText.isEmpty()) {
			try (Connection connection = Database.establishConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(
							"SELECT * FROM course WHERE LOWER(COURSE_ID) LIKE ? OR LOWER(COURSENAME) LIKE ?")) {

				String searchPattern = "%" + searchText.toLowerCase() + "%";
				preparedStatement.setString(1, searchPattern);
				preparedStatement.setString(2, searchPattern);

				ResultSet resultSet = preparedStatement.executeQuery();

				// Clear existing items in the TableView
				CourseTable.getItems().clear();
				CourseTable.getColumns().clear();

				// Create columns dynamically based on the result set metadata
				for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
					final int j = i - 1;
					TableColumn<ObservableList<Object>, Object> column = new TableColumn<>(
							resultSet.getMetaData().getColumnName(i));
					column.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
					CourseTable.getColumns().add(column);
				}

				// Add data to the TableView
				ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();
				while (resultSet.next()) {
					ObservableList<Object> row = FXCollections.observableArrayList();
					for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
						row.add(resultSet.getObject(i));
					}
					data.add(row);
				}
				CourseTable.setItems(data);

			} catch (SQLException e) {
				e.printStackTrace();
				showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
			}
		} else {
			// If the search text is empty, show all data
			getCourseData();
		}
	}

	// ***** SCENE FUNCTIONS *****
	public void Logout() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
			Parent adminScene = loader.load();
			Scene scene = new Scene(adminScene);
			Stage stage = (Stage) logout_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Home() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("admin.fxml"));
			Parent adminScene = loader.load();
			Scene scene = new Scene(adminScene);
			Stage stage = (Stage) home_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Exit() {
		System.exit(0);
	}

	// ***** MISCELLANEOUS FUNCTIONS *****
	private void showAlert(String title, String content, Alert.AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}

	private void reset() {
		courseID_tf.clear();
		CName.clear();
		DeptID.clear();
		lecture.clear();
		lab.clear();
		semoffer.clear();
	}

}
