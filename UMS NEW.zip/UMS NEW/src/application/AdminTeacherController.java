package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminTeacherController {

	@FXML
	Button Home;

	@FXML
	Button LogOut;

	@FXML
	Button Add;

	@FXML
	Button Update;

	@FXML
	Button Delete;

	@FXML
	Button Reset;

	@FXML
	Button Exit;

	@FXML
	TextField facultyID;

	@FXML
	TextField FName;

	@FXML
	TextField LName;

	@FXML
	TextField Contact;

	@FXML
	TextField Email;

	@FXML
	TextField DeptID;

	@FXML
	TextField Gender;

	@FXML
	TableView<ObservableList<Object>> TeacherTable;

	@FXML
	public void initialize() {
		getTeacherData();
//		populateFieldsFromSelectedRow();
	}

	public void getTeacherData() {
		try (Connection connection = Database.establishConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM faculty")) {

			// Clear existing items in the TableView
			TeacherTable.getItems().clear();
			TeacherTable.getColumns().clear();

			// Create columns dynamically based on the result set metadata
			for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
				final int j = i - 1;
				TableColumn<ObservableList<Object>, Object> column = new TableColumn<>(
						resultSet.getMetaData().getColumnName(i));
				column.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
				TeacherTable.getColumns().add(column);
			}

			// Add data to the TableView
			ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();
			while (resultSet.next()) {
				ObservableList<Object> row = FXCollections.observableArrayList();
				for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
					row.add(resultSet.getObject(i));
				}
				data.add(row);
			}
			TeacherTable.setItems(data);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	// ***** CRUD OPERATIONS FOR FACULTY *****
	public void addFaculty() {
		try {
			String facultyId = facultyID.getText();
			String firstName = FName.getText();
			String lastName = LName.getText();
			String contact = Contact.getText();
			String email = Email.getText();
			String deptId = DeptID.getText();
			String gender = Gender.getText();

			// Check if any of the required fields is empty
			if (facultyId.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || contact.isEmpty() || email.isEmpty()
					|| deptId.isEmpty() || gender.isEmpty()) {
				// Display an alert or handle the empty fields as needed
				System.out.println("All fields must be filled!");
				showAlert("Error", "All fields must be filled!", Alert.AlertType.ERROR);
				return;
			}
			if (!gender.matches("[MF]")) {
				// Invalid gender, show an error message or handle it accordingly
				showAlert("Error", "Gender should be either 'M' or 'F'", Alert.AlertType.ERROR);
				return;
			}

			// Database query to insert a new faculty
			String insertQuery = "INSERT INTO faculty (FACULTY_ID, FIRSTNAME, LASTNAME, CONTACT, EMAIL, DEPT_ID, GENDER) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?)";

			try (Connection connection = Database.establishConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

				preparedStatement.setString(1, facultyId);
				preparedStatement.setString(2, firstName);
				preparedStatement.setString(3, lastName);
				preparedStatement.setString(4, contact);
				preparedStatement.setString(5, email);
				preparedStatement.setString(6, deptId);
				preparedStatement.setString(7, gender);

				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					System.out.println("Faculty added successfully!");
					showAlert("Success", "Faculty added successfully!", Alert.AlertType.INFORMATION);

				} else {
					System.out.println("Failed to add faculty!");
					showAlert("Error", "Failed to add faculty!", Alert.AlertType.ERROR);
				}

				// Refresh the TableView after adding faculty
				getTeacherData();

			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteFaculty() {
		try {
			// Get the selected faculty ID from the table
			ObservableList<Object> selectedRow = TeacherTable.getSelectionModel().getSelectedItem();
			if (selectedRow == null) {
				showAlert("Error", "Please select a faculty to delete.", Alert.AlertType.ERROR);
				return;
			}

			String facultyID = selectedRow.get(0).toString();

			// Delete the faculty from the database
			try (Connection connection = Database.establishConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement("DELETE FROM faculty WHERE FACULTY_ID = ?")) {

				preparedStatement.setString(1, facultyID);
				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					showAlert("Success", "Faculty deleted successfully.", Alert.AlertType.INFORMATION);

					// Refresh the table after deletion
					getTeacherData();
				} else {
					showAlert("Error", "Failed to delete faculty.", Alert.AlertType.ERROR);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateFaculty() {
		try {
			// Get the selected faculty ID from the table
			ObservableList<Object> selectedRow = TeacherTable.getSelectionModel().getSelectedItem();
			if (selectedRow == null) {
				showAlert("Error", "Please select a faculty to update.", Alert.AlertType.ERROR);
				return;
			}

			String facultyID = selectedRow.get(0).toString();

			// Get updated information from UI components
			String newFirstName = FName.getText();
			String newLastName = LName.getText();
			String newContact = Contact.getText();
			String newEmail = Email.getText();
			String newDeptID = DeptID.getText();
			String newGender = Gender.getText();

			// Update the faculty in the database
			try (Connection connection = Database.establishConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(
							"UPDATE faculty SET FIRSTNAME=?, LASTNAME=?, CONTACT=?, EMAIL=?, DEPT_ID=?, GENDER=? WHERE FACULTY_ID=?")) {

				preparedStatement.setString(1, newFirstName);
				preparedStatement.setString(2, newLastName);
				preparedStatement.setString(3, newContact);
				preparedStatement.setString(4, newEmail);
				preparedStatement.setString(5, newDeptID);
				preparedStatement.setString(6, newGender);
				preparedStatement.setString(7, facultyID);

				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					showAlert("Success", "Faculty updated successfully.", Alert.AlertType.INFORMATION);

					// Refresh the table after update
					getTeacherData();
				} else {
					showAlert("Error", "Failed to update faculty.", Alert.AlertType.ERROR);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void populateFieldsFromSelectedRow() {
		try {
			// Get the selected row
			ObservableList<Object> selectedRow = TeacherTable.getSelectionModel().getSelectedItem();
			if (selectedRow == null) {
				showAlert("Error", "Please select a faculty to update.", Alert.AlertType.ERROR);
				return;
			}

			// Populate text fields with the selected row data
			facultyID.setText(selectedRow.get(0).toString());
			FName.setText(selectedRow.get(1).toString());
			LName.setText(selectedRow.get(2).toString());
			Contact.setText(selectedRow.get(3).toString());
			Email.setText(selectedRow.get(4).toString());
			DeptID.setText(selectedRow.get(5).toString());
			Gender.setText(selectedRow.get(6).toString());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ***** SCENE FUNCTIONS *****
	public void Logout() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
			Parent adminScene = loader.load();
			Scene scene = new Scene(adminScene);
			Stage stage = (Stage) LogOut.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Home() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("admin.fxml"));
			Parent adminScene = loader.load();
			Scene scene = new Scene(adminScene);
			Stage stage = (Stage) Home.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Exit() {
		System.exit(0);
	}

	// ***** MISCELLANEOUS FUNCTIONS *****
	private void showAlert(String title, String content, Alert.AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}

	public void reset() {
		facultyID.setText("");
		FName.setText("");
		LName.setText("");
		Contact.setText("");
		Email.setText("");
		DeptID.setText("");
		Gender.setText("");
	}
}
