package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

public class Database {
	private static Connection databaseConnection;
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/apex";
	private static final String USER = "root";
	private static final String PASSWORD = "admin";

	public static Connection establishConnection() {
		try {
			databaseConnection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
			// Optionally, you can print a message to confirm the connection
			System.out.println("Connected to the database!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return databaseConnection;

	}

	public static void insertData(String schemaName, String tableName, Map<String, Object> data) {
		try {
			Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);

			StringBuilder insertQuery = new StringBuilder("INSERT INTO ");
			insertQuery.append(schemaName).append(".").append(tableName).append(" (");

			for (String columnName : data.keySet()) {
				insertQuery.append(columnName).append(", ");
			}

			insertQuery.setLength(insertQuery.length() - 2); // Remove the trailing comma and space
			insertQuery.append(") VALUES (");

			for (int i = 0; i < data.size(); i++) {
				insertQuery.append("?, ");
			}

			insertQuery.setLength(insertQuery.length() - 2); // Remove the trailing comma and space
			insertQuery.append(")");

			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery.toString());

			int parameterIndex = 1;
			for (Object value : data.values()) {
				preparedStatement.setObject(parameterIndex++, value);
			}

			int rowsAffected = preparedStatement.executeUpdate();

			preparedStatement.close();
			connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}