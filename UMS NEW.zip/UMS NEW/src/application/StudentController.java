package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class StudentController {

	@FXML
	Button home_btn;

	@FXML
	Button transcript_btn;

	@FXML
	Button marks_btn;

	@FXML
	Button fee_btn;

	@FXML
	Button course_btn;

	@FXML
	Button logout_btn;

	@FXML
	Label id_lbl;

	@FXML
	Label name_lbl;

	@FXML
	Label gender_lbl;

	@FXML
	Label section_lbl;

	@FXML
	Label degree_lbl;

	@FXML
	Label address_lbl;

	@FXML
	Label email_lbl;

	@FXML
	Label contact_lbl;

	@FXML
	BarChart<String, Number> Attendance_chart;

	@FXML
	BarChart<String, Number> SemesterGPA_chart;

	@FXML
	AnchorPane HomePane;

//	TRANSCRIPT VARIABLES HERE
	@FXML
	Label t_header_lbl;

	@FXML
	Label t_name_lbl;

	@FXML
	Label t_section_lbl;

	@FXML
	Label t_dept_lbl;

	@FXML
	Button t_home_btn;

	@FXML
	Button t_course_btn;

	@FXML
	Button t_transcript_btn;

	@FXML
	Button t_logOut_btn;

	@FXML
	Button t_marks_btn;

	@FXML
	Button t_fees_btn;

	@FXML
	Label t_name_lbl_ans;

	@FXML
	Label t_sec_lbl_ans;

	@FXML
	Label t_dept_lbl_ans;

	@FXML
	Label t_credit_lbl_ans;

	@FXML
	TableView<ObservableList<Object>> TranscriptTable;

	@FXML
	AnchorPane TranscriptPane;

	public static Map<String, String> studentData = new HashMap<>();

//	***** INITIALIZATION FUNCTIONS *****
	@FXML
	public void initializeStudentData(String studentId) {
		String id = studentId;

		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(
						"SELECT STUDENT_ID, FIRSTNAME, LASTNAME, GENDER, SECTION_ID, DEPT_ID, ADDRESS, EMAIL, CONTACT FROM STUDENT WHERE STUDENT_ID = ?")) {

			preparedStatement.setString(1, studentId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					studentData.put("STUDENT_ID", resultSet.getString("STUDENT_ID"));
					studentData.put("FIRSTNAME", resultSet.getString("FIRSTNAME"));
					studentData.put("LASTNAME", resultSet.getString("LASTNAME"));
					studentData.put("GENDER", resultSet.getString("GENDER"));
					studentData.put("SECTION_ID", resultSet.getString("SECTION_ID"));
					studentData.put("DEPT_ID", resultSet.getString("DEPT_ID"));
					studentData.put("ADDRESS", resultSet.getString("ADDRESS"));
					studentData.put("EMAIL", resultSet.getString("EMAIL"));
					studentData.put("CONTACT", resultSet.getString("CONTACT"));

					id_lbl.setText(resultSet.getString("STUDENT_ID"));
					name_lbl.setText(resultSet.getString("FIRSTNAME") + " " + resultSet.getString("LASTNAME"));
					gender_lbl.setText(resultSet.getString("GENDER"));
					section_lbl.setText(resultSet.getString("SECTION_ID"));
					degree_lbl.setText(resultSet.getString("DEPT_ID"));
					address_lbl.setText(resultSet.getString("ADDRESS"));
					email_lbl.setText(resultSet.getString("EMAIL"));
					contact_lbl.setText(resultSet.getString("CONTACT"));

					initializeStudentTranscript(studentId);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void initializeStudentTranscript(String studentId) {
		// Set student information in labels
		t_name_lbl_ans.setText(getFirstName() + " " + getLastName());
		t_sec_lbl_ans.setText(getSectionId());
		t_dept_lbl_ans.setText(getDeptId());

		ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();

		// Fetch transcript data from the database based on student ID
		String query = "SELECT * FROM transcript WHERE STUDENT_ID = ?";
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query)) {

			preparedStatement.setString(1, studentId);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				// Get column names
				int numCols = resultSet.getMetaData().getColumnCount();
				for (int i = 1; i <= numCols; i++) {
					final int j = i - 1;
					TableColumn<ObservableList<Object>, Object> col = new TableColumn<>(
							resultSet.getMetaData().getColumnName(i));
					col.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
					TranscriptTable.getColumns().add(col);
				}

				// Get row data
				while (resultSet.next()) {
					ObservableList<Object> row = FXCollections.observableArrayList();
					for (int i = 1; i <= numCols; i++) {
						row.add(resultSet.getObject(i));
					}
					data.add(row);
				}

				// Set data into the table
				TranscriptTable.setItems(data);

			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

//	***** MAP FOR STUDENT *****
	public static Map<String, String> getStudentData() {
		return studentData;
	}

//	GETTERS FOR THE STUDENT DATA************************************
	public String getStudentID() {
		return studentData.get("STUDENT_ID");
	}

	public static String getFirstName() {
		return studentData.get("FIRSTNAME");
	}

	public static String getLastName() {
		return studentData.get("LASTNAME");
	}

	public static String getGender() {
		return studentData.get("GENDER");
	}

	public static String getSectionId() {
		return studentData.get("SECTION_ID");
	}

	public static String getDeptId() {
		return studentData.get("DEPT_ID");
	}

	public static String getAddress() {
		return studentData.get("ADDRESS");
	}

	public static String getEmail() {
		return studentData.get("EMAIL");
	}

	public static String getContact() {
		return studentData.get("CONTACT");
	}

	// *******SCENE FUNCTIONS*******************************************************
	public void Logout() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
			Parent loginScene = loader.load();
			Scene scene = new Scene(loginScene);
			Stage stage = (Stage) logout_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Home() {
		HomePane.setVisible(true);
		TranscriptPane.setVisible(false);
	}

	public void Transcript() {
		HomePane.setVisible(false);
		TranscriptPane.setVisible(true);
	}

}
