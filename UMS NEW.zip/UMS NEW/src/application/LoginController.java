package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import application.Database;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginController {

	@FXML
	private TextField username_tf;

	@FXML
	private PasswordField password_tf;

	@FXML
	private Button reset_btn;

	@FXML
	private Button login_btn;

	@FXML
	private AnchorPane Login_anchorpane;

	@FXML
	private Label login_result_lbl;

	private Connection databaseConnection;

	@FXML
	public void initialize() {
		// Apply slide-in animation to the loginBox
		TranslateTransition slideIn = new TranslateTransition(Duration.millis(1000), Login_anchorpane);
		slideIn.setFromY(-1000);
		slideIn.setToY(0);
		slideIn.setCycleCount(1);
		slideIn.play();
	}

	public void handleLogin() {
		String username = username_tf.getText();
		String password = password_tf.getText();

		if (username.isEmpty() || password.isEmpty()) {
			login_result_lbl.setText("Please enter both username and password.");
			return;
		}

		char first_char = username.charAt(0);

		if (first_char == 'A' || first_char == 'a') {
			try (Connection connection = Database.establishConnection()) {
				String query = "SELECT * FROM ADMIN WHERE USERNAME=?";
				try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
					preparedStatement.setString(1, username);
					try (ResultSet resultSet = preparedStatement.executeQuery()) {
						if (resultSet.next()) {
							String storedPassword = resultSet.getString("A_PASSWORD");
							if (password.equals(storedPassword)) {
								// Successfully logged in
								openAdminPanel();
							} else {
								login_result_lbl.setText("Invalid password");
							}
						} else {
							login_result_lbl.setText("User not found");
						}
					}
				}
			} catch (SQLException e) {
				login_result_lbl.setText("Login error");
				e.printStackTrace();
			}
		} else if (first_char == 'K' || first_char == 'k') {
			loginStudent(username, password);
		} else if (first_char == 'T' || first_char == 't') {
			loginFaculty(username, password);
		}

	}

	private void openAdminPanel() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("admin.fxml"));
			Parent root = loader.load();
			Stage stage = new Stage();
			stage.setTitle("University Management System - Admin Panel");
			stage.setScene(new Scene(root));
			stage.show();

			Stage loginStage = (Stage) login_btn.getScene().getWindow();
			loginStage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Login student********************************
	public void loginStudent(String studentId, String password) {
		String query = "SELECT * FROM STUDENT WHERE STUDENT_ID=? AND PASSWORD=?";

		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query)) {

			preparedStatement.setString(1, studentId);
			preparedStatement.setString(2, password);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					openStudentPanel(studentId);
				} else {
					login_result_lbl.setText("Invalid Student Id or password");
				}
			}
		} catch (SQLException e) {
			login_result_lbl.setText("Login error");
			e.printStackTrace();
		}
	}

	private void openStudentPanel(String studentId) {
		try {
			String id = studentId;
			FXMLLoader loader = new FXMLLoader(getClass().getResource("StudentMain.fxml"));
			Parent studentScene = loader.load();
			StudentController studentController = loader.getController();
			studentController.initializeStudentData(id);
			// below using the newly created student class
			Student student = new Student();
			student.initializeStudentData(id);
			Scene scene = new Scene(studentScene);
			Stage stage = (Stage) login_btn.getScene().getWindow();
			stage.setTitle("University Management System - Student Panel");
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Login faculty********************************
	public void loginFaculty(String facultyId, String password) {
		String query = "SELECT * FROM FACULTY WHERE FACULTY_ID=? AND PASSWORD=?";

		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query)) {

			preparedStatement.setString(1, facultyId);
			preparedStatement.setString(2, password);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					openFacultyPanel(facultyId);
				} else {
					login_result_lbl.setText("Invalid Faculty Id or password");
				}
			}
		} catch (SQLException e) {
			login_result_lbl.setText("Login error");
			e.printStackTrace();
		}
	}

	private void openFacultyPanel(String facultyId) {
		try {
			String id = facultyId;
			FXMLLoader loader = new FXMLLoader(getClass().getResource("TeacherHome.fxml"));
			Parent facultyScene = loader.load();
			TeacherController facultyController = loader.getController();
			facultyController.initializeFacultyData(id);
			Scene scene = new Scene(facultyScene);
			Stage stage = (Stage) login_btn.getScene().getWindow();
			stage.setTitle("University Management System - Faculty Panel");
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Reset(ActionEvent event) {
		username_tf.clear();
		password_tf.clear();
		login_result_lbl.setText("");
	}

}
