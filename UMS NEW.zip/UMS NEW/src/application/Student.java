package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Student {
	// Define private fields to store student information
	private String studentId;
	private String firstName;
	private String gender;
	private String sectionId;
	private String deptId;
	private String address;
	private String email;
	private String contact;

	public void initializeStudentData(String studentId) {
		try {
			Connection connection = Database.establishConnection();
			String query = "SELECT STUDENT_ID, FIRSTNAME, GENDER, SECTION_ID, DEPT_ID, ADDRESS, EMAIL, CONTACT FROM STUDENT WHERE STUDENT_ID = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, studentId);

			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				// Set values to global variables
				this.studentId = resultSet.getString("STUDENT_ID");
				this.firstName = resultSet.getString("FIRSTNAME");
				this.gender = resultSet.getString("GENDER");
				this.sectionId = resultSet.getString("SECTION_ID");
				this.deptId = resultSet.getString("DEPT_ID");
				this.address = resultSet.getString("ADDRESS");
				this.email = resultSet.getString("EMAIL");
				this.contact = resultSet.getString("CONTACT");

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Add getter methods for accessing these variables
	public String getStudentId() {
		return studentId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getGender() {
		return gender;
	}

	public String getSectionId() {
		return sectionId;
	}

	public String getDeptId() {
		return deptId;
	}

	public String getAddress() {
		return address;
	}

	public String getEmail() {
		return email;
	}

	public String getContact() {
		return contact;
	}

}
