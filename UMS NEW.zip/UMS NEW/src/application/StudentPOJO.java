package application;

public class StudentPOJO {

	String studentID;
	String firstName;
	String lastName;
	String dob;
	String sectionID;
	String deptID;
	String gender;
	String email;
	String address;

	public StudentPOJO(String studentID, String firstName, String lastName, String dob, String sectionID, String deptID,
			String gender, String email, String address) {
		this.studentID = studentID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.sectionID = sectionID;
		this.deptID = deptID;
		this.gender = gender;
		this.email = email;
		this.address = address;
	}

	public String getStudentID() {
		return studentID;
	}

	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getSectionID() {
		return sectionID;
	}

	public void setSectionID(String sectionID) {
		this.sectionID = sectionID;
	}

	public String getDeptID() {
		return deptID;
	}

	public void setDeptID(String deptID) {
		this.deptID = deptID;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
