package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AdminMainScreenController {

	@FXML
	Button student_btn;

	@FXML
	Button faculty_btn;

	@FXML
	Button courses_btn;

	public void AccessStudent(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("admin_student.fxml"));
			Parent nextScene = loader.load();
			Scene scene = new Scene(nextScene);
			Stage stage = (Stage) student_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void AccessFaculty(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("admin_teacher.fxml"));
			Parent nextScene = loader.load();
			Scene scene = new Scene(nextScene);
			Stage stage = (Stage) faculty_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public void AccessCourse(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("admin_courses.fxml"));
			Parent nextScene = loader.load();
			Scene scene = new Scene(nextScene);
			Stage stage = (Stage) courses_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
