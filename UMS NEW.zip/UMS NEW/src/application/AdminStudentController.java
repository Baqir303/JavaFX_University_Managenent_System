package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class AdminStudentController {
	@FXML
	BarChart<String, Number> studentBarChart;

	@FXML
	Button AddStudent_btn;

	@FXML
	Button StudentRegistration_btn;

	@FXML
	Button StudentTranscript_btn;

	@FXML
	Button Logout_btn;

	@FXML
	Button Home_btn;

	@FXML
	TextField studentID_tf;

	@FXML
	TextField firstname_tf;

	@FXML
	TextField lastname_tf;

	@FXML
	TextField address_tf;

	@FXML
	TextField email_tf;

	@FXML
	TextField contact_tf;

	@FXML
	TextField dept_tf;

	@FXML
	TextField gender_tf;

	@FXML
	TextField sectionID_tf;

	@FXML
	DatePicker DOB;

	@FXML
	TextField search_tf;

	@FXML
	AnchorPane adminStudentHomePane;

	// ***** ADMIN STUDENT FUNCTIONS VARIABLES *****
	@FXML
	AnchorPane adminStudentFunctions;

	@FXML
	Button sp_home_btn;

	@FXML
	Button sp_add_btn;

	@FXML
	Button sp_delete_btn;

	@FXML
	Button sp_update_btn;

	@FXML
	Button sp_reset_btn;

	@FXML
	Button exit_btn;

	@FXML
	TableView<ObservableList<Object>> adminStudentTable;

//	***** ADMIN STUDENT REGISTRATION VARIABLES *****
	@FXML
	TableView<ObservableList<Object>> studentTable;

	@FXML
	TableView<ObservableList<Object>> courseTable;

	@FXML
	TableView<ObservableList<Object>> courseRegistrationTable;

	@FXML
	TextField course_reg_tf;

	@FXML
	Button home_btn_reg;

	@FXML
	Button Logout_btn_reg;

	@FXML
	Button Exit_btn_reg;

	@FXML
	AnchorPane adminStudentRegistrationPane;

	@FXML
	TextField student_search_reg_tf;

	@FXML
	public void initialize() {
		animateBarChartsliding();
		getStudentData();
		getCourseDataForRegistration();
		getStudentDataForRegistration();
		getCourseRegistrationData();
		displayEnrollmentChart();
		search_tf.textProperty().addListener((observable, oldValue, newValue) -> searchStudent(newValue));
		student_search_reg_tf.textProperty()
				.addListener((observable, oldValue, newValue) -> searchStudentForRegistration(newValue));
		course_reg_tf.textProperty().addListener((observable, oldValue, newValue) -> searchCourse(newValue));
	}

	public void getStudentData() {
		try (Connection connection = Database.establishConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM STUDENT")) {

			// Clear existing data in the TableView
			adminStudentTable.getColumns().clear();
			adminStudentTable.getItems().clear();

			// Get column names
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numCols = metaData.getColumnCount();
			for (int i = 1; i <= numCols; i++) {
				final int j = i - 1;
				TableColumn<ObservableList<Object>, Object> col = new TableColumn<>(metaData.getColumnName(i));
				col.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
				adminStudentTable.getColumns().add(col);
			}

			// Get row data
			while (resultSet.next()) {
				ObservableList<Object> row = FXCollections.observableArrayList();
				for (int i = 1; i <= numCols; i++) {
					row.add(resultSet.getObject(i));
				}
				adminStudentTable.getItems().add(row);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void displayEnrollmentChart() {
		try (Connection connection = Database.establishConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(
						"SELECT DEPT_ID, COUNT(STUDENT_ID) AS TOTAL_STUDENTS FROM ENROLLMENT GROUP BY DEPT_ID")) {

			// Clear existing data in the BarChart
			studentBarChart.getData().clear();

			// Create a new series for the BarChart
			XYChart.Series<String, Number> series = new XYChart.Series<>();

			// Populate series with data
			while (resultSet.next()) {
				String deptId = resultSet.getString("DEPT_ID");
				int totalStudents = resultSet.getInt("TOTAL_STUDENTS");

				// Create an XYChart.Data with a different color for each department
				XYChart.Data<String, Number> data = new XYChart.Data<>(deptId, totalStudents);
				setDepartmentColor(deptId, data);

				series.getData().add(data);
			}

			// Add series to the BarChart
			studentBarChart.getData().add(series);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void setDepartmentColor(String deptId, XYChart.Data<String, Number> data) {
		// Assigning a color based on the department ID
		String color;
		switch (deptId) {
		case "BS(SE)":
			color = "blue";
			break;
		case "BS(CS)":
			color = "green";
			break;
		case "BS(CYS)":
			color = "red";
			break;
		case "BS(FT)":
			color = "purple";
			break;
		case "BS(AI)":
			color = "yellow";
			break;
		default:
			color = "gray";
			break;
		}

		// Set the color for the data point
		Node node = data.getNode();
		if (node != null) {
			node.setStyle("-fx-bar-fill: " + color + ";");
		}
	}

	private void animateBarChartsliding() {
		double fromX = 600; // Starting X position for the chart
		double toX = 0; // Final X position for the chart
		Duration duration = Duration.millis(1000); // Animation duration (1 second)

		TranslateTransition translateTransition = new TranslateTransition(duration, studentBarChart);
		translateTransition.setFromX(fromX);
		translateTransition.setToX(toX);
		translateTransition.play();
	}

//***** SCENE FUNCTIONS *****
	public void Logout() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
			Parent adminScene = loader.load();
			Scene scene = new Scene(adminScene);
			Stage stage = (Stage) Logout_btn.getScene().getWindow();
			stage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Home() {
		adminStudentHomePane.setVisible(true);
	}

	public void StudentPropertiesScreen() {
		adminStudentHomePane.setVisible(false);
		adminStudentFunctions.setVisible(true);
	}

	public void sphomeBtn() {
		adminStudentFunctions.setVisible(false);
		initialize();
		adminStudentHomePane.setVisible(true);
	}

	public void StudentRegistrationScene() {
		adminStudentHomePane.setVisible(false);
		adminStudentRegistrationPane.setVisible(true);
	}

	public void Exit() {
		System.exit(0);
	}

//***** CRUD OPERATIONS FOR STUDENT *****
	public void addStudent() {

		String stdID = studentID_tf.getText();
		String FName = firstname_tf.getText();
		String LName = lastname_tf.getText();
		String address = address_tf.getText();
		String email = email_tf.getText();
		String contact = contact_tf.getText();
		String dept = dept_tf.getText();
		String gender = gender_tf.getText();

		if (stdID.isEmpty() || FName.isEmpty() || LName.isEmpty() || address.isEmpty() || email.isEmpty()
				|| contact.isEmpty() || dept.isEmpty() || gender.isEmpty()) {
			showAlert("Error", "All fields must be filled!", Alert.AlertType.ERROR);
			return;
		}

		if (!gender.matches("[MF]")) {
			// Invalid gender, show an error message or handle it accordingly
			showAlert("Error", "Gender should be either 'M' or 'F'", Alert.AlertType.ERROR);
			return;
		}

		try (Connection connection = Database.establishConnection()) {
			String query = "INSERT INTO student (STUDENT_ID, FIRSTNAME, LASTNAME, ADDRESS, DOB, EMAIL, CONTACT, DEPT_ID, SECTION_ID, GENDER) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setString(1, studentID_tf.getText());
				preparedStatement.setString(2, firstname_tf.getText());
				preparedStatement.setString(3, lastname_tf.getText());
				preparedStatement.setString(4, address_tf.getText());
				preparedStatement.setDate(5, java.sql.Date.valueOf(DOB.getValue()));
				preparedStatement.setString(6, email_tf.getText());
				preparedStatement.setString(7, contact_tf.getText());
				preparedStatement.setString(8, dept_tf.getText());
				preparedStatement.setInt(9, Integer.parseInt(sectionID_tf.getText()));
				preparedStatement.setString(10, gender_tf.getText());

				int affectedRows = preparedStatement.executeUpdate();

				if (affectedRows > 0) {
					// Data inserted successfully
					showAlert("Student Added", "Student data has been added successfully.",
							Alert.AlertType.INFORMATION);
					// You may want to refresh the table or perform other actions here
					getStudentData();
				} else {
					showAlert("Error", "Failed to add student data.", Alert.AlertType.ERROR);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Database Error", "An error occurred while interacting with the database.",
					Alert.AlertType.ERROR);
		}
	}

	public void deleteSelectedStudent() {
		// Get the selected row
		ObservableList<Object> selectedRow = adminStudentTable.getSelectionModel().getSelectedItem();

		if (selectedRow != null) {
			// Assuming the student ID is in the first column (index 0)
			String studentId = selectedRow.get(0).toString();

			// delete the student
			String deleteStudentQuery = "DELETE FROM STUDENT WHERE STUDENT_ID = ?";
			try (Connection connection = Database.establishConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(deleteStudentQuery)) {

				preparedStatement.setString(1, studentId);
				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					// Deletion successful, show an alert
					showAlert("Success", "Student deleted successfully!", Alert.AlertType.INFORMATION);

					// Refresh the table after deletion
					getStudentData();
				} else {
					// No rows affected, show an alert
					showAlert("Error", "Failed to delete student.", Alert.AlertType.ERROR);
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			// No row selected, display an error or prompt
			showAlert("Error", "No student selected for deletion.", Alert.AlertType.INFORMATION);
		}
	}

	public void saveUpdatedStudent() {
		String studentId = studentID_tf.getText();
		String firstName = firstname_tf.getText();
		String lastName = lastname_tf.getText();
		String address = address_tf.getText();
		String email = email_tf.getText();
		String contact = contact_tf.getText();
		String deptId = dept_tf.getText();
		String gender = gender_tf.getText();
		String sectionId = sectionID_tf.getText();
		LocalDate dob = DOB.getValue();

		String updateStudentQuery = "UPDATE STUDENT SET FIRSTNAME=?, LASTNAME=?, ADDRESS=?, "
				+ "EMAIL=?, CONTACT=?, DEPT_ID=?, GENDER=?, SECTION_ID=?, DOB=? WHERE STUDENT_ID=?";

		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(updateStudentQuery)) {

			preparedStatement.setString(1, firstName);
			preparedStatement.setString(2, lastName);
			preparedStatement.setString(3, address);
			preparedStatement.setString(4, email);
			preparedStatement.setString(5, contact);
			preparedStatement.setString(6, deptId);
			preparedStatement.setString(7, gender);
			preparedStatement.setString(8, sectionId);
			preparedStatement.setDate(9, Date.valueOf(dob));
			preparedStatement.setString(10, studentId);

			int rowsAffected = preparedStatement.executeUpdate();

			if (rowsAffected > 0) {
				// Update successful, show an alert
				showAlert("Success", "Student updated successfully!", Alert.AlertType.INFORMATION);

				// Refresh the table after update
				getStudentData();
			} else {
				// No rows affected, show an alert
				showAlert("Error", "Failed to update student.", Alert.AlertType.ERROR);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void searchStudent(String query) {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(
						"SELECT * FROM student WHERE STUDENT_ID LIKE ? OR FIRSTNAME LIKE ? OR LASTNAME LIKE ?")) {

			preparedStatement.setString(1, "%" + query + "%");
			preparedStatement.setString(2, "%" + query + "%");
			preparedStatement.setString(3, "%" + query + "%");

			ResultSet resultSet = preparedStatement.executeQuery();

			// Clear existing items in the TableView
			adminStudentTable.getItems().clear();
			adminStudentTable.getColumns().clear();

			// Create columns dynamically based on the result set metadata
			for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
				final int j = i - 1;
				TableColumn<ObservableList<Object>, Object> column = new TableColumn<>(
						resultSet.getMetaData().getColumnName(i));
				column.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
				adminStudentTable.getColumns().add(column);
			}

			// Add data to the TableView
			ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();
			while (resultSet.next()) {
				ObservableList<Object> row = FXCollections.observableArrayList();
				for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
					row.add(resultSet.getObject(i));
				}
				data.add(row);
			}
			adminStudentTable.setItems(data);

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	// ***** ADMIN STUDENT REGISTRATION FUNCTIONS *****

	public void getStudentDataForRegistration() {
		try (Connection connection = Database.establishConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM STUDENT")) {

			// Clear existing data in the TableView
			studentTable.getColumns().clear();
			studentTable.getItems().clear();

			// Get column names
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numCols = metaData.getColumnCount();
			for (int i = 1; i <= numCols; i++) {
				final int j = i - 1;
				TableColumn<ObservableList<Object>, Object> col = new TableColumn<>(metaData.getColumnName(i));
				col.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
				studentTable.getColumns().add(col);
			}

			// Get row data
			while (resultSet.next()) {
				ObservableList<Object> row = FXCollections.observableArrayList();
				for (int i = 1; i <= numCols; i++) {
					row.add(resultSet.getObject(i));
				}
				studentTable.getItems().add(row);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void getCourseDataForRegistration() {
		try (Connection connection = Database.establishConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM COURSE")) {

			// Clear existing data in the TableView
			courseTable.getColumns().clear();
			courseTable.getItems().clear();
			// Get column names
			ResultSetMetaData metaData = resultSet.getMetaData();
			int numCols = metaData.getColumnCount();
			for (int i = 1; i <= numCols; i++) {
				final int j = i - 1;
				TableColumn<ObservableList<Object>, Object> col = new TableColumn<>(metaData.getColumnName(i));
				col.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
				courseTable.getColumns().add(col);
			}

			// Get row data
			while (resultSet.next()) {
				ObservableList<Object> row = FXCollections.observableArrayList();
				for (int i = 1; i <= numCols; i++) {
					row.add(resultSet.getObject(i));
				}
				courseTable.getItems().add(row);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database Error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	boolean isValidCourse(String courseId) {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM course WHERE COURSE_ID = ?")) {

			preparedStatement.setString(1, courseId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				return resultSet.next(); // If there is a result, the course ID is valid
			}

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
			return false; // consider the course ID invalid
		}
	}

	boolean isAlreadyRegistered(String studentId, String courseId) {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM courseRegistration WHERE STUDENT_ID = ? AND COURSE_ID = ?")) {

			preparedStatement.setString(1, studentId);
			preparedStatement.setString(2, courseId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				return resultSet.next(); // If there is a result, the student is already registered for the course
			}

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
			return true;
// Assume an error, and consider the student already registered (to prevent unintended registrations)
		}
	}

	public void searchCourse(String searchQuery) {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM course WHERE COURSE_ID LIKE ? OR COURSENAME LIKE ?")) {

			preparedStatement.setString(1, "%" + searchQuery + "%");
			preparedStatement.setString(2, "%" + searchQuery + "%");

			ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					ObservableList<Object> row = FXCollections.observableArrayList();
					for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
						row.add(resultSet.getObject(i));
					}
					data.add(row);
				}
			}

			courseTable.setItems(data);

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	public void searchStudentForRegistration(String query) {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(
						"SELECT * FROM student WHERE STUDENT_ID LIKE ? OR FIRSTNAME LIKE ? OR LASTNAME LIKE ?")) {

			preparedStatement.setString(1, "%" + query + "%");
			preparedStatement.setString(2, "%" + query + "%");
			preparedStatement.setString(3, "%" + query + "%");

			ResultSet resultSet = preparedStatement.executeQuery();

			// Clear existing items in the TableView
			studentTable.getItems().clear();
			studentTable.getColumns().clear();

			// Create columns dynamically based on the result set metadata
			for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
				final int j = i - 1;
				TableColumn<ObservableList<Object>, Object> column = new TableColumn<>(
						resultSet.getMetaData().getColumnName(i));
				column.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
				studentTable.getColumns().add(column);
			}

			// Add data to the TableView
			ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();
			while (resultSet.next()) {
				ObservableList<Object> row = FXCollections.observableArrayList();
				for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
					row.add(resultSet.getObject(i));
				}
				data.add(row);
			}
			studentTable.setItems(data);

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	public void registerCourses() {
		ObservableList<Object> selectedStudent = studentTable.getSelectionModel().getSelectedItem();
		ObservableList<Object> selectedCourse = courseTable.getSelectionModel().getSelectedItem();
		if (selectedStudent != null) {
			// Assuming the student ID and Course ID is in the first column respectively
			String selectedStudentId = selectedStudent.get(0).toString();
			String enteredCourseId = selectedCourse.get(0).toString();

			if (isValidCourse(enteredCourseId) && !isAlreadyRegistered(selectedStudentId, enteredCourseId)) {
				registerStudentForCourse(selectedStudentId, enteredCourseId);
				showAlert("Success", "Course registered successfully.", Alert.AlertType.INFORMATION);
				getCourseRegistrationData(); // Refresh the course registration table
			} else {
				showAlert("Error", "Invalid course ID or student already registered for the course.",
						Alert.AlertType.ERROR);
			}
		} else {
			showAlert("Error", "Please select a student from the table.", Alert.AlertType.ERROR);
		}
	}

	public void registerStudentForCourse(String studentId, String courseId) {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("INSERT INTO courseRegistration (STUDENT_ID, COURSE_ID) VALUES (?, ?)")) {

			preparedStatement.setString(1, studentId);
			preparedStatement.setString(2, courseId);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

	public void getCourseRegistrationData() {
		try (Connection connection = Database.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM courseRegistration")) {

			ObservableList<ObservableList<Object>> data = FXCollections.observableArrayList();

			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				// Clear existing items and columns
				courseRegistrationTable.getItems().clear();
				courseRegistrationTable.getColumns().clear();

				// Create columns dynamically based on the result set metadata
				for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
					final int j = i - 1;
					TableColumn<ObservableList<Object>, Object> column = new TableColumn<>(
							resultSet.getMetaData().getColumnName(i));
					column.setCellValueFactory(param -> new SimpleObjectProperty<>(param.getValue().get(j)));
					courseRegistrationTable.getColumns().add(column);
				}

				// Add data to the TableView
				while (resultSet.next()) {
					ObservableList<Object> row = FXCollections.observableArrayList();
					for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
						row.add(resultSet.getObject(i));
					}
					data.add(row);
				}
			}

			courseRegistrationTable.setItems(data);

		} catch (SQLException e) {
			e.printStackTrace();
			showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
		}
	}

//	*****DELETING COURSE REGISTRATION*****
	public void deleteRegistration() {
		// Assuming you have a selected row in the courseRegistrationTable
		ObservableList<Object> selectedRow = courseRegistrationTable.getSelectionModel().getSelectedItem();

		if (selectedRow != null) {
			String studentId = selectedRow.get(0).toString();
			String courseId = selectedRow.get(1).toString();

			try (Connection connection = Database.establishConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(
							"DELETE FROM courseRegistration WHERE STUDENT_ID = ? AND COURSE_ID = ?")) {

				preparedStatement.setString(1, studentId);
				preparedStatement.setString(2, courseId);

				int affectedRows = preparedStatement.executeUpdate();
				if (affectedRows > 0) {
					showAlert("Success", "Registration deleted successfully.", Alert.AlertType.INFORMATION);
					getCourseRegistrationData(); // Refresh the table
				} else {
					showAlert("Error", "Failed to delete registration.", Alert.AlertType.ERROR);
				}

			} catch (SQLException e) {
				e.printStackTrace();
				showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
			}
		} else {
			showAlert("Error", "Please select a registration to delete.", Alert.AlertType.ERROR);
		}
	}

	// ***** MISCELLANEOUS FUNCTIONS *****
	private void showAlert(String title, String content, Alert.AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}

	public void reset() {
		address_tf.setText("");
		studentID_tf.setText("");
		email_tf.setText("");
		gender_tf.setText("");
		contact_tf.setText("");
		dept_tf.setText("");
		firstname_tf.setText("");
		lastname_tf.setText("");
		sectionID_tf.setText("");
		DOB.setValue(null);

	}

}
